to make this program work you must put all 
stroop, backwards and forward extra (the ones with the .txt) files into one folder. 

whatever you name this folder will be the name of the sheet and excell file.

to run it will first propt the user for the folder (wave you wish to parse)

then it will propmt you again. this will be the expot destination.


thanks again cody fredericks

--------------
notes 
parsed wave1 everything seems to look ok
subject 13 stroop RT was off. at further looking into it seems somone posted a duplacate in the excell sheet. 

this sould be fully ready but more waves to test could help 
06/17/2018


contact at cjf@iastate.edu
